ReadMe - C19464094


Classes
	WordSearchEngine Contains the code for the GUI and the Search Engine
Control calls the WordSearchEngine Class


Description
	A GUI appears with a textbox asking for a word to search for. The Program then searches the files in the directory and returns
the files and the amount of times the word appears in the files.

The WordSearchEngine was originally just the GUI, However I couldn't figure out how to get the input from the GUI and use it in another class
without using the Actionlistener, So I just made the Actionlistener search for the word in the files when the button is pushed.

If I had more time I would have added an option to that allows the user to change the directory and 
make the search not case-sensitive that way you get the amount of times the word 'the' and 'The' appears in the files together instead of separately.